/**
 * 데이터베이스 사용하기
 * 
 * 설정 파일과 데이터베이스 스키마 파일들을 로딩하는 모듈 파일 추가하기
 *
 * config.js
 * database/database.js
 *
 * 웹브라우저에서 아래 주소의 페이지를 열고 웹페이지에서 요청
 * (먼저 사용자 추가 후 로그인해야 함)
 *    http://localhost:3000/public/login.html
 *    http://localhost:3000/public/adduser2.html
 *
 * @date 2016-11-10
 * @author Mike
 */


// Express 기본 모듈 불러오기
var express = require('express')
  , http = require('http')
  , path = require('path');

// Express의 미들웨어 불러오기
var bodyParser = require('body-parser')
  , cookieParser = require('cookie-parser')
  , static = require('serve-static')
  , errorHandler = require('errorhandler');

// 에러 핸들러 모듈 사용
var expressErrorHandler = require('express-error-handler');

// Session 미들웨어 불러오기
var expressSession = require('express-session');
 

// 설정을 위한 모듈 파일 로딩
var config = require('./config');

// 데이터베이스 스키마 파일들을 위한 모듈 파일 로딩
var database = require('./database/database');


// 익스프레스 객체 생성
var app = express();

// 설정 파일에 들어있는 port 정보 사용하여 포트 설정
console.log('config.server_port : %d', config.server_port);
app.set('port', config.server_port);

// body-parser를 이용해 application/x-www-form-urlencoded 파싱
app.use(bodyParser.urlencoded({ extended: false }))

// body-parser를 이용해 application/json 파싱
app.use(bodyParser.json())

// public 폴더를 static으로 오픈
app.use('/public', express.static(path.join(__dirname, 'public')));
 
// cookie-parser 설정
app.use(cookieParser());

// 세션 설정
app.use(expressSession({
	secret:'my key',
	resave:true,
	saveUninitialized:true
}));
 

// 설정 파일의 정보를 이용해 라우팅 함수 설정
config.initRoutes(app);



// 404 에러 페이지 처리
var errorHandler = expressErrorHandler({
 static: {
   '404': './public/404.html'
 }
});

//app.use( expressErrorHandler.httpError(404) );
//app.use( errorHandler );


//===== 서버 시작 =====//

// 프로세스 종료 시에 데이터베이스 연결 해제
process.on('SIGTERM', function () {
    console.log("프로세스가 종료됩니다.");
    app.close();
});

app.on('close', function () {
	console.log("Express 서버 객체가 종료됩니다.");
	if (database) {
		database.close();
	}
});

// Express 서버 시작
http.createServer(app).listen(app.get('port'), function() {
  console.log('서버가 시작되었습니다. 포트 : ' + app.get('port'));

  // 데이터베이스 모듈 파일을 이용해 데이터베이스 초기화
  database.init(app, config);
   
});

//==========================================================================
var fs = require('fs');
var get_urlPage = function (req, res) {
    var pageName = 'public'+req.url+'.html';
    console.log("get_urlPage(req.url:"+req.url+") page:"+pageName);
    
    fs.readFile(pageName, function (error, data) {
        console.log("-> page : "+pageName+",  error : "+error);  
        if(error) {
			res.writeHead('200', {'Content-Type':'text/html;charset=utf8'});
			res.write('<h2> ['+pageName+']  page not found</h1>');
			res.end();
			return;
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
    });
}
var get_rootPage = function (req, res) {
	req.url = '/login';
	get_urlPage(req, res);
}
//==============================================
app.get('/',            get_rootPage);
app.get('/login',       get_urlPage);
app.get('/adduser',     get_urlPage);
app.get('/listuser',    get_urlPage);
app.get('/updateuser',  get_urlPage);
app.get('*',            get_urlPage);
//==============================================

